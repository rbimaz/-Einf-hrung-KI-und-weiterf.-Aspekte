package dhbw.ai.search.impl;


import dhbw.ai.search.interfaces.IEdge;
import dhbw.ai.search.interfaces.IVertex;

import java.util.*;

public class Vertex implements IVertex {


    @Override
    public ArrayList<Edge> getEdges(){

        Collections.sort(edgeList, new Comparator<Edge>() {
            @Override
            public int compare(Edge e1, Edge e2) {
                String name1 = e1.getDestination().name;
                String name2 = e2.getDestination().name;
                return name1.compareToIgnoreCase(name2);
            }

        });
        return edgeList;
    }




    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Vertex vertex = (Vertex) o;
        return this.name.equals(vertex.name) && (this.edgeList.size() == vertex.edgeList.size());
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, edgeList);
    }
}
