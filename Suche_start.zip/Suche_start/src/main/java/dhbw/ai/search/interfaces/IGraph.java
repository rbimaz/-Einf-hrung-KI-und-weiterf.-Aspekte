package dhbw.ai.search.interfaces;

import dhbw.ai.search.impl.Vertex;

public interface IGraph {
    boolean addEdge(Vertex source, Vertex destination, int weight);
    boolean addEdge(Vertex source, Vertex destination);
    boolean addVertex(Vertex v);
}
