package dhbw.ai.search.impl;

import dhbw.ai.search.interfaces.IEdge;
import dhbw.ai.search.interfaces.IVertex;

public class Edge implements IEdge {
    
}
