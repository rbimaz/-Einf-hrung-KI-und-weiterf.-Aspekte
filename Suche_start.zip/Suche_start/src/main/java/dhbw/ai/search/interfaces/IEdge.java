package dhbw.ai.search.interfaces;

import dhbw.ai.search.impl.Vertex;

public interface IEdge {
    int getWeight();
    Vertex getSource();
    Vertex getDestination();
}
