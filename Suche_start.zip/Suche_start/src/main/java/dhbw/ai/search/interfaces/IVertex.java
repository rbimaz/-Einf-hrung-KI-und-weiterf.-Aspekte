package dhbw.ai.search.interfaces;

import dhbw.ai.search.impl.Edge;
import dhbw.ai.search.impl.Vertex;

import java.util.LinkedList;
import java.util.List;

public interface IVertex {
    String getName();

    List<Edge> getEdges();

}
