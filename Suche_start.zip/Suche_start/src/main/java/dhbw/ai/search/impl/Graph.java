package dhbw.ai.search.impl;

import dhbw.ai.search.interfaces.IGraph;

import java.util.*;

public class Graph implements IGraph {


}

