package dhbw.ai.search;

import dhbw.ai.search.impl.Graph;
import dhbw.ai.search.impl.Vertex;

public class App
{


    public static void main(String[] argv){


    }
}
