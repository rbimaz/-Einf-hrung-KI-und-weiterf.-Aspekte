package dhbw.ai.search.impl;

import org.junit.jupiter.api.Test;

class GraphTest {


    @Test
    void breadthFirstSearch() {
        Vertex a = new Vertex("A");
        Vertex b = new Vertex("B");
        Vertex c = new Vertex("C");
        Vertex d = new Vertex("D");
        Vertex e = new Vertex("E");
        Vertex f = new Vertex("F");
        Vertex g = new Vertex("G");
        Vertex z = new Vertex("Z");

        Graph bfsGraph = new Graph();

        bfsGraph.addEdge(a, b);
        bfsGraph.addEdge(b, c);
        bfsGraph.addEdge(c, f);
        bfsGraph.addEdge(d, a);
        bfsGraph.addEdge(e, d);
        bfsGraph.addEdge(e, b);
        bfsGraph.addEdge(f, e);
        bfsGraph.addEdge(f, z);
        bfsGraph.addEdge(g, e);
        bfsGraph.addEdge(z, g);


        System.out.println("Reihenfolge bei der Breitensuche:");
        bfsGraph.breadthFirstSearch(f);





    }

    @Test
    void depthFirstSearch() {
        Vertex a = new Vertex("A");
        Vertex b = new Vertex("B");
        Vertex c = new Vertex("C");
        Vertex d = new Vertex("D");
        Vertex e = new Vertex("E");
        Vertex f = new Vertex("F");
        Vertex g = new Vertex("G");
        Vertex z = new Vertex("Z");

        Graph bfsGraph = new Graph();

        bfsGraph.addEdge(a, b);
        bfsGraph.addEdge(b, c);
        bfsGraph.addEdge(c, f);
        bfsGraph.addEdge(d, a);
        bfsGraph.addEdge(e, d);
        bfsGraph.addEdge(e, b);
        bfsGraph.addEdge(f, e);
        bfsGraph.addEdge(f, z);
        bfsGraph.addEdge(g, e);
        bfsGraph.addEdge(z, g);

        System.out.println("Reihenfolge bei der Tiefensuche:");
        bfsGraph.depthFirstSearch(f);
    }
}

