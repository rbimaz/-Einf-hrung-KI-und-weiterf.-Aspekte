package dhbw.ai.search.impl;

import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class WikiLinksExtractor {

    final WikiFetcher wf;
    public WikiLinksExtractor() {

       wf = new WikiFetcher();
    }

    public List<String> getValidLinks(String url) throws IOException {
        List<String> urls = new ArrayList<>();
        try{

            Elements paragraphs = wf.fetchWikipedia(url);
            WikiParser wp = new WikiParser(paragraphs);
            urls = wp.findUrls();
        }
        catch(Exception ex){
            System.out.println(ex.toString());
            ex.printStackTrace();
        }
        return urls;
    }
}
