package dhbw.ai.search.impl;


import org.jsoup.nodes.Element;
        import org.jsoup.nodes.Node;
        import org.jsoup.nodes.TextNode;
        import org.jsoup.select.Elements;

import java.util.*;

public class WikiParser {

    // the list of paragraphs we should search
    private Elements paragraphs;

    private Deque<String> parenthesisStack;


    /**
     * Initializes a WikiParser with a list of Elements.
     *
     * @param paragraphs
     */
    public WikiParser(Elements paragraphs) {
        this.paragraphs = paragraphs;
        this.parenthesisStack = new ArrayDeque<String>();
    }

    /**
     * Searches the paragraphs for a valid link.
     *
     * Warns if a paragraph ends with unbalanced parentheses.
     *
     * @return
     */
    public Element findFirstLink() {
        for (Element paragraph: paragraphs) {
            Element firstLink = findFirstLinkPara(paragraph);
            if (firstLink != null) {
                return firstLink;
            }
            if (!parenthesisStack.isEmpty()) {
                System.err.println("Warning: unbalanced parentheses.");
            }
        }
        return null;
    }

    public List<Element> findLinks(){
        ArrayList<Element> result = new ArrayList<>();
        try{
            for (Element paragraph: paragraphs) {
                Element firstLink = findFirstLinkPara(paragraph);
                if (firstLink != null) {
                    //return firstLink;
                    result.add(firstLink);
                }
                if (!parenthesisStack.isEmpty()) {
                    System.err.println("Warning: unbalanced parentheses.");
                }
            }
        }
        catch(java.util.NoSuchElementException ex){
            System.out.println("Exception:"+ ex.toString());
                    ex.printStackTrace();
        }
        return result;

    }

    public List<String> findUrls(){
        ArrayList<String> result = new ArrayList<>();
        try{
            for (Element paragraph: paragraphs) {
                Element firstLink = findFirstLinkPara(paragraph);

                if (firstLink != null) {
                    //result.add(firstLink);
                    String url = firstLink.attr("abs:href");
                    result.add(url);
                }
                if (!parenthesisStack.isEmpty()) {
                    System.err.println("Warning: unbalanced parentheses.");
                }
            }
        }
        catch(java.util.NoSuchElementException ex){
            System.out.println("Exception:"+ ex.toString());
            ex.printStackTrace();
        }
        return result;

    }

    /**
     * Returns the first valid link in a paragraph, or null.
     *
     * @param root
     */
    private Element findFirstLinkPara(Node root) {
        // create an Iterable that traverses the tree
        Iterable<Node> nt = new WikiNodeIterable(root);

        // loop through the nodes
        for (Node node: nt) {
            // process TextNodes to get parentheses
            if (node instanceof TextNode) {
                //processTextNode((TextNode) node);
            }
            // process elements to get find links
            if (node instanceof Element) {
                Element firstLink = checkElement((Element) node);
                if (firstLink != null) {
                    return firstLink;
                }
            }
        }
        return null;
    }

    /**
     * Returns the element if it is a valid link, null otherwise.
     *
     *
     *
     * @param elt
     */
    private Element checkElement(Element elt) {
        //System.out.println(elt.tagName());
        if (isValidLink(elt)) {
            return elt;
        }
        return null;
    }

    /**
     * Checks whether a link is value.
     *
     * @param elt
     * @return
     */
    private boolean isValidLink(Element elt) {
        if (!elt.tagName().equals("a")) {
            return false;
        }
        if (isItalic(elt)) {
            return false;
        }
        // in parenthesis
        if (isInParens(elt)) {
            return false;
        }
        // a bookmark
        if (startsWith(elt, "#")) {
            return false;
        }

        if (startsWith(elt, "/wiki/Help:")) {
            return false;
        }

        if(endsWith(elt,".svg")){
            return false;
        }
        if(!contains(elt, "https://en.wikipedia.org")){
            //return false;
        }
        if(contains(elt,"#cite_ref")){
            return false;
        }
        if(contains(elt,"#cite_note")){
            return false;
        }
        if(contains(elt,"index.php?")){
            return false;
        }
        if(contains(elt,"api.php?")){
            return false;
        }

        return true;
    }

    /**
     * Checks whether a link starts with a given String.
     *
     * @param elt
     * @param s
     * @return
     */
    private boolean startsWith(Element elt, String s) {

        return (elt.attr("href").startsWith(s));
    }

    private boolean endsWith(Element elt, String s) {

        return (elt.attr("href").endsWith(s));
    }

    private boolean contains(Element elt, String s) {

        return (elt.attr("href").contains(s));
    }

    /**
     * Checks whether the element is in parentheses (possibly nested).
     *
     * @param elt
     * @return
     */
    private boolean isInParens(Element elt) {
        return !parenthesisStack.isEmpty();
    }

    /**
     * Checks whether the element is in italics.
     *
     * (Either a "i" or "em" tag)
     *
     * @param start
     * @return
     */
    private boolean isItalic(Element start) {
        // follow the parent chain until we get to null
        for (Element elt=start; elt != null; elt = elt.parent()) {
            if (elt.tagName().equals("i") || elt.tagName().equals("em")) {
                return true;
            }
        }
        return false;
    }

    /**
     * Processes a text node, splitting it up and checking parentheses.
     *
     * @param node
     */
    private void processTextNode(TextNode node) {
        StringTokenizer st = new StringTokenizer(node.text(), " ()", true);
        while (st.hasMoreTokens()) {
            String token = st.nextToken();
            // System.out.print(token);
            if (token.equals("(")) {
                parenthesisStack.push(token);
            }
            if (token.equals(")")) {
                if (parenthesisStack.isEmpty()) {
                    System.err.println("Warning: unbalanced parentheses.");
                }
                parenthesisStack.pop();
            }
        }
    }
}

