package dhbw.ai.search.impl;

import java.io.IOException;
import java.util.*;

import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class WikiRacer {





    public static void main(String[] args) throws IOException {

        String source = "https://en.wikipedia.org/wiki/Java_(programming_language)";
        String destination = "https://en.wikipedia.org/wiki/Philosophy";

    }

    public static void traverseWikipediaDfs(String source, String destination, int limit) throws IOException {

    }

    public static void traverseWikipediaBfs(String source, String destination, int limit) throws IOException {

    }
    private static void print(String msg, Object... args) {
        System.out.println(String.format(msg, args));
    }


}
