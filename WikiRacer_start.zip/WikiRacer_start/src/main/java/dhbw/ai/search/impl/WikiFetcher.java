package dhbw.ai.search.impl;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.SocketTimeoutException;
import java.net.URL;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class WikiFetcher {
    private long lastRequestTime = -1;
    private long minInterval = 1000;

    /**
     * Fetches and parses a URL string, returning a list of paragraph elements.
     *
     * @param url
     * @return
     * @throws IOException
     */
    public Elements fetchWikipedia(String url)  {
        sleepIfNeeded();

        // download and parse the document
        Elements paras = new Elements();
        try{
            Connection conn = Jsoup.connect(url);
            Document doc = conn.get();
            Element content = doc.getElementById("mw-content-text");
            paras = content.select("p");
            return paras;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return paras;


    }

    public List<String> extractUrls(String url)  {
        sleepIfNeeded();
        List<String> result = new ArrayList<>();

        // download and parse the document
        Elements paras = new Elements();
        try{
            Connection conn = Jsoup.connect(url);

            Document doc = conn.get();


            Element content = doc.getElementById("bodyContent");

            Elements links = content.select("a[href]");

            //Elements links = doc.select("a[href]");
            for (Element link : links) {
                //System.out.println(link.text() +"=>"+  link.attr("abs:href"));
                if(link.attr("abs:href").contains("#mw-head")) continue;
                if(link.attr("abs:href").contains("#searchInput")) continue;
                String resultUrl = link.attr("abs:href");
                if(isValidUrl(resultUrl)){
                    result.add(resultUrl);
                }

            }



        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return result;


    }

    private boolean isValidUrl(String resultUrl) {
        boolean result = true;
        if(resultUrl.endsWith(".svg")){
            result = false;
        }
        if(resultUrl.contains(".png")){
            return false;
        }
        if(!resultUrl.contains("https://en.wikipedia.org")){
            result = false;
        }
        if(resultUrl.contains("#cite_ref")){
            result = false;
        }
        if(resultUrl.contains("#cite_note")){
            result = false;
        }
        if(resultUrl.contains("index.php?")){
            result = false;
        }
        if(resultUrl.contains("api.php?")){
            result = false;
        }
        if(resultUrl.contains("#")){
            result = false;
        }
        if(resultUrl.contains(".jpg")){
            return false;
        }
        if(resultUrl.contains("Ignore_all_rules")){
            return false;
        }
        if(resultUrl.contains("Wikiproject_Spoken_Wikipedia")){
            return false;
        }
        if(resultUrl.contains("Portal")){
            return false;
        }
        if(resultUrl.contains("User")){
            return false;
        }
        if(resultUrl.contains("Category")){
            return false;
        }
        if(resultUrl.contains("WikiProject")){
            return false;
        }
        if(resultUrl.contains("Special:Search")){
            return false;
        }
        if(resultUrl.contains("Wikipedia:Questions")){
            return false;
        }
        if(resultUrl.contains("disambiguation")){
            return false;
        }
        if(resultUrl.contains("Media_type")){
            return false;
        }

        if(resultUrl.contains("Naming_conventions")){
            return false;
        }
        if(resultUrl.contains("What_adminship_is_not")){
            return false;
        }
        if(resultUrl.contains("Help:")){
            return false;
        }
        if(resultUrl.contains("CITEHOW")){
            return false;
        }
        if(resultUrl.contains("CITENEED")){
            return false;
        }

        if(resultUrl.contains("Wikipedia:PCR")){
            return false;
        }
        if(resultUrl.contains("Wikipedia:Reviewing")){
            return false;
        }
        if(resultUrl.contains("Wikipedia:Page")){
            return false;
        }
        if(resultUrl.contains("Wikipedia_talk")){
            return false;
        }
        if(resultUrl.contains("Special:")){
            return false;
        }
        if(resultUrl.contains("User:")){
            return false;
        }
        if(resultUrl.contains("File:")){
            return false;
        }
        if(resultUrl.contains(":Translators")){
            return false;
        }
        if(resultUrl.contains(":Translation")){
            return false;
        }
        if(resultUrl.contains(":ADMINP")){
            return false;
        }

        if(resultUrl.contains(":Pending")){
            return false;
        }

        if(resultUrl.contains(":PRESS")){
            return false;
        }
        if(resultUrl.contains("Template:")){
            return false;
        }
        if(resultUrl.contains("When_to_cite")){
            return false;
        }
        if(resultUrl.contains("https://en.wikipedia.org/wiki/English_Wikipedia")){
            return false;
        }
        if(resultUrl.contains("https://en.wikipedia.org/wiki/Style_manual")){
            return false;
        }
        if(resultUrl.contains("Manual_of_Style")){
            return false;
        }
        if(resultUrl.contains("General_disclaimer")){
            return false;
        }
        if(resultUrl.contains("Talk:")){
            return false;
        }
        if(resultUrl.contains("PLWABN")){
            return false;
        }
        if(resultUrl.contains("WorldCat_Identities")){
            return false;
        }
        if(resultUrl.contains("Privacy_law")){
            return false;
        }
        if(resultUrl.contains("Text_of_Creative_Commons")){
            return false;
        }
        if(resultUrl.contains("WikiNode")){
            return false;
        }
        if(resultUrl.contains("MoonEdit")){
            return false;
        }
        if(resultUrl.contains("Redirects_for_discussion")){
            return false;
        }
        if(resultUrl.contains("File_Upload_Wizard")){
            return false;
        }
        if(resultUrl.contains("MediaWiki_talk:")){
            return false;
        }
        if(resultUrl.contains("Template_talk:")){
            return false;
        }
        return result;
    }

    /**
     * Reads the contents of a Wikipedia page from src/resources.
     *
     * @param url
     * @return
     * @throws IOException
     */
    public Elements readWikipedia(String url) throws IOException {
        URL realURL = new URL(url);

        // assemble the file name
        String slash = File.separator;
        String filename = "resources" + slash + realURL.getHost() + realURL.getPath();

        // read the file
        InputStream stream = WikiFetcher.class.getClassLoader().getResourceAsStream(filename);
        Document doc = Jsoup.parse(stream, "UTF-8", filename);

        // parse the contents of the file
        // TODO: factor out the following repeated code
        Element content = doc.getElementById("mw-content-text");
        Elements paras = content.select("p");
        return paras;
    }

    /**
     * Rate limits by waiting at least the minimum interval between requests.
     */
    private void sleepIfNeeded() {
        if (lastRequestTime != -1) {
            long currentTime = System.currentTimeMillis();
            long nextRequestTime = lastRequestTime + minInterval;
            if (currentTime < nextRequestTime) {
                try {
                    //System.out.println("Sleeping until " + nextRequestTime);
                    Thread.sleep(nextRequestTime - currentTime);
                } catch (InterruptedException e) {
                    System.err.println("Warning: sleep interrupted in fetchWikipedia.");
                }
            }
        }
        lastRequestTime = System.currentTimeMillis();
    }

    /**
     * @param args
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {
        WikiFetcher wf = new WikiFetcher();
        String url = "https://en.wikipedia.org/wiki/Java_(programming_language)";
        Elements paragraphs = wf.readWikipedia(url);

        for (Element paragraph: paragraphs) {
            System.out.println(paragraph);
        }
    }
}
