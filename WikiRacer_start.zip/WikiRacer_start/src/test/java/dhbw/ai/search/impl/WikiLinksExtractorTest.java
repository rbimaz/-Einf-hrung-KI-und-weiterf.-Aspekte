package dhbw.ai.search.impl;

import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.List;

class WikiLinksExtractorTest {

    @Test
    void getValidUrls() throws IOException {
        WikiLinksExtractor extractor = new WikiLinksExtractor();
        List<String> urls = extractor.getValidLinks("https://en.wikipedia.org/wiki/Object");
    }
}