package dhbw.ai.search.impl;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class WikiFetcherTest {

    @Test
    void extractUrlsTest() {
        WikiFetcher fetcher = new WikiFetcher();
        List<String> urls =fetcher.extractUrls("https://en.wikipedia.org/wiki/Object");

    }
}